import { Navigate, useRoutes } from 'react-router-dom';
import DefaultLayout from "../layout/defaultLayout";

import TokenChecker from '../pages/tokenchecker';
// import Home from "../pages/home";;

export default function Router() {
  return useRoutes([
    { 
      path: '/',
      children: [
        { path: '/', element: <Navigate to='/tokenchecker' replace /> },
        { path: '/tokenchecker', element: <TokenChecker /> }, 
        { path: '/tokenchecker/:address', element: <TokenChecker /> }, 
      ]
    },
    {
      element: <DefaultLayout />,
      children: [
        { path: '/home', element: <TokenChecker /> },
      ]
    }
  ])
}