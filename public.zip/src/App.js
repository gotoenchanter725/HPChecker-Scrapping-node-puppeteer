import Routes from "./config/route";
import "./App.scss";

function App() {
  return (
    <div className="App">
      <Routes />
    </div>
  );
}

export default App;
