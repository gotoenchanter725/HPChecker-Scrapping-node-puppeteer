import React, { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import { Box, Button, Stack } from "@mui/material";
import MenuItem from '@mui/material/MenuItem';
import InputLabel from '@mui/material/InputLabel';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import Input from "../../components/input";
import "./tokenchecker.scss";
import axios from "axios";
import {
    changeCurrentTokenIshoneypot,
    changeCurrentTokenHoneypotState,
    changeCurrentTokenIsRugpull,
    changeCurrentTokenRugpullState,
    changeNetwork,
    changeContractAddress,
    changeTokenHolders,
    changeTokenName,
    changeTokenSymbol,
    changeTokenOwner,
    changeTotalSupply,
    changeCirculatingSupply,
    changeSourceCode,
    changeConfirmVerify,
    changeTransfer,
    changeCirculatingSupplyGivenAddress,
} from "../../../redux/actions";
import { useDispatch } from "react-redux";
import { BASE_URL } from "../../../config/const";

export default function Noshitcheck() {
    // const honeypotMessage = "Show the error message";
    const dispatch = useDispatch();
    const [address, setAddress] = useState('');
    const [error, setError] = useState("");
    const navigate = useNavigate();

    const [netType, setNetType] = useState('eth');

    const handleChange = (event) => {
        setNetType(event.target.value);
    };

    const CheckHandle = async () => {
        navigate(`/tokenchecker/${address}`);
        if (!String(address)) {
            setError("Hey! I need a token contract to check how it smells. Please provide it!");
            return;
        }
        if (String(address).substr(0, 2) != "0x" || String(address).length != 42) {
            setError("This token address is invalid");
            return;
        }
        setError("");

        // ------- Token address that user set matched info show -----------

        dispatch(changeCurrentTokenIshoneypot("loading"));
        dispatch(changeCurrentTokenIsRugpull("loading"));
        dispatch(changeNetwork(netType));
        dispatch(changeContractAddress(address));
        dispatch(changeTokenName("loading"));
        dispatch(changeTokenSymbol("loading"));
        dispatch(changeTokenOwner("loading"));
        dispatch(changeTotalSupply("loading"));
        dispatch(changeCirculatingSupply("loading"));
        dispatch(changeConfirmVerify("loading"));
        dispatch(changeSourceCode("loading"));
        dispatch(changeCurrentTokenHoneypotState(""));
        dispatch(changeCurrentTokenRugpullState(""));
        dispatch(changeTokenHolders(undefined));

        await axios.post(`${BASE_URL}/api/${netType}/check-honeypot`, {
            contract_address: address
        }).then(response => {
            console.log(response.data);
            dispatch(changeCurrentTokenIshoneypot(response.data.data));
            dispatch(changeCurrentTokenHoneypotState(response.data.info));
        });

        await axios.post(`${BASE_URL}/api/${netType}/check-rugpull`, {
            contract_address: address
        }).then(response => {
            dispatch(changeCurrentTokenIsRugpull(response.data.text));
            dispatch(changeCurrentTokenRugpullState(response.data.info));
            dispatch(changeTokenHolders(response.data.list));
        });

        await axios.post(`${BASE_URL}/api/${netType}/check-detail`, {
            contract_address: address
        }).then(response => {
            if (response.data.status == "1") {
                const data = response.data;
                dispatch(changeTokenName(data.tokenName));
                dispatch(changeTokenSymbol(data.tokenSymbol));
                dispatch(changeTokenOwner(data.tokenOwner));
                dispatch(changeTotalSupply(data.totalSupply));
                dispatch(changeCirculatingSupply(data.circulatingSupply));
                dispatch(changeSourceCode((data.sourceCode && data.sourceCode.name != 'Error') ? "Move into Code" : "Can't Code."));
                dispatch(changeConfirmVerify(data.confirmVerify));
            } else {
            }
        });

        await axios.post(`${BASE_URL}/api/${netType}/check-transfer`, {
            contract_address: address,
            another_address: address
        }).then(response => {
            if (response.data.status == '1') {
                const data = response.data;
                dispatch(changeTransfer(data.transfer));
                dispatch(changeCirculatingSupplyGivenAddress(data.circulatingSupplyGivenAddress));
            } else {
            }
        })
    }

    return (
        <div className="tokencheck-container">
            <Stack direction="column" sx={{ margin: "auto" }} alignItems="center">
                <Stack direction={{ lg: "row", md: "row", sm: "column", xs: "column" }} alignItems="center" justifyContent="space-around" sx={{ marginBottom: "20px" }}>
                    <h2>NOSHIT CHECKER</h2>
                    <FormControl className="netType-wrap" sx={{ width: 200 }}>
                        {/* <InputLabel id="demo-simple-select-autowidth-label">NET</InputLabel> */}
                        <Select
                            labelId="demo-simple-select-autowidth-label"
                            id="demo-simple-select-autowidth"
                            value={netType}
                            onChange={handleChange}
                            autoWidth
                            // readOnly
                            label="nettype"
                            sx={{ color: "var(--primary)" }}
                        >
                            <MenuItem value={'eth'}>ETH MainNetWork</MenuItem>
                            <MenuItem value={'bsc'}>BSC MainNetWork</MenuItem>
                        </Select>
                    </FormControl>
                </Stack>
                <Stack direction={{ lg: "row", md: "row", sm: "column", xs: "column" }} alignItems="center" justifyContent="space-around">
                    <Stack className="address-wrap" sx={{ marginRight: "10px" }} direction="row" alignItems="center" justifyContent="space-around">
                        <label htmlFor="token" style={{ marginRight: "10px" }}>Token Address</label>
                        <Input id="token" value={address} changeHandle={setAddress} />
                        {
                            error && <span className="error">{error}</span>
                        }
                    </Stack>
                    <Button onClick={CheckHandle} className={"custom-btn " + (error ? "sm-mb" : "")} variant="contained">NOSHIT CHECK</Button>
                </Stack>
            </Stack>
        </div>
    )
}