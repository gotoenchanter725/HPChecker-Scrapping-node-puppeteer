import React, { useState, useEffect } from "react";
import { Box, Card, Stack } from "@mui/material";
import NormalCard from "../../components/normalCard";
import infoUrl from "../../../assets/image/info.jpg";
import './index.scss';
import { useSelector } from "react-redux";
import axios from "axios";
import { VapingRoomsRounded } from "@mui/icons-material";
import loadingUrl from "../../../assets/image/loading.gif";
import { BASE_URL } from "../../../config/const";
export default function HoneyAndRugh() {
    var [currentTokenIshoneypot, currentTokenHoneypotState] = useSelector((state) => {
        return [state.data.currentTokenIshoneypot, state.data.currentTokenHoneypotState];
    });
    var [currentTokenIsRugpull, currentTokenRugpullState] = useSelector((state) => {
        return [state.data.currentTokenIsRugpull, state.data.currentTokenRugpullState];
    });

    return (
        <NormalCard className="honeyandrugh" title="Honey Pot and Rugpull" component={
            <>
                <Stack className="hr-row" mb={4} direction="row" alignItems="center" justifyContent={"space-between"}>
                    <label>Honeypot</label>
                    <span>{(currentTokenIshoneypot=="loading"?(<img className="loading" src={loadingUrl} />):currentTokenIshoneypot)}</span>
                    <div className="tooltip-wrap">
                        <img src={infoUrl} />
                        <span className="tooltip-text">{currentTokenHoneypotState?currentTokenHoneypotState:"Honeypot"}</span>
                    </div>
                </Stack>
                <Stack className="hr-row" direction="row" alignItems="center" justifyContent={"space-between"}>
                    <label>Rugpull</label>
                    <span>{(currentTokenIsRugpull=="loading"?(<img className="loading" src={loadingUrl} />):currentTokenIsRugpull)}</span>
                    <div className="tooltip-wrap">
                        <img src={infoUrl} />
                        <span className="tooltip-text">{currentTokenRugpullState?currentTokenRugpullState:"Rugpull"}</span>
                    </div>
                </Stack>
            </>
        }>
        </NormalCard>
    )
}