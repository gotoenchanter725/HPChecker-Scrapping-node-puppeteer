module.exports = app => {
  const eth = require("../controllers/eth.controllers.js");
  const bsc = require("../controllers/bsc.controllers.js");
  var router = require("express").Router();
  router.post("/check_eth_honeypot/", eth.honey_check);
  router.post("/check_bsc_honeypot/", bsc.honey_check);
  router.post("/check_eth_rugpull/", eth.rugpull_check);
  router.post("/check_bsc_rugpull/", bsc.rugpull_check);
  app.use('/api', router);
};