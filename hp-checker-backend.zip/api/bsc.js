const { honey_check, rugpull_check, detail_check } = require("../controllers/bsc.controllers.js");
var router = require("express").Router();

// ************* MakeBid ***************************
router.post("/check-honeypot", honey_check);
router.post("/check-rugpull", rugpull_check);
router.post("/check-detail", detail_check);

module.exports = router;