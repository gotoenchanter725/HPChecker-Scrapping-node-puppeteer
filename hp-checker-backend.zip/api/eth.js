const { honey_check, rugpull_check } = require("../controllers/eth.controllers.js");
var router = require("express").Router();

// ************* MakeBid ***************************
router.post("/check-honeypot", honey_check);
router.post("/check-rugpull", rugpull_check);

module.exports = router;