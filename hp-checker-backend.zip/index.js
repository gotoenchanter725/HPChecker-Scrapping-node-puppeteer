const express = require("express");
const cors = require("cors");

const bsc = require("./api/bsc");
const eth = require("./api/eth");

const app = express();
var corsOption = {
    origin: "*"
};
app.use(cors(corsOption));
app.use(express.json({ extended: false }));
app.use(express.urlencoded({extended: true}));

app.get("/", (req, res) => {
    res.json({ message: "Welcome to hp-checker-api application." });
});

app.use("/api/eth", eth);
app.use("/api/bsc", bsc);

const PORT = process.env.PORT || 8080;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT} .`);
});
