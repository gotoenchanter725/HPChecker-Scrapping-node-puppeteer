const Web3 = require("web3");
const web3 = new Web3('https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161');
const API_KEY = process.env.API_KEY;
const axios = require('axios');
const uniswap_address_v3 = "0xE592427A0AEce92De3Edee1F18E0157C05861564"
const uniswap_address_v2 = "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D";
const puppeteer = require("puppeteer");
var request = require("request");
require("dotenv").config();

exports.honey_check = async (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  contract_address = req.body.contract_address;
  let rst;
  await check_honey(contract_address, (err, data) => {
    if (err) {
      rst = {
        status: "error",
        error: err, 
        data: "Honeypot!!!"
      }
      // res.send("Honeypot!!!")//add error 
    }
    else {
      rst = {
        statue: "success",
        data: data
      }
      // res.send(data);
    }
  });
  console.log(rst);
  res.send(rst);
};

//7MU9TK2MM5SPAA3DFXN6X9P59EFSMJK1Q8
const check_honey = async (contract_address, result) => {
  let contract_abi;
  let uniswap_balance_v2, uniswap_balance_v3;
  const url = 'https://api.etherscan.io/api?module=contract&action=getabi&address=' + contract_address + '&apikey=' + API_KEY;
  await axios.get(url)
    .then(response => {
      contract_abi = response.data.result;
      return;
    })
    .catch(error => {
      result(error, null);
      return;
    });

  try {
    const UserContract = new web3.eth.Contract(JSON.parse(contract_abi), contract_address);
    uniswap_balance_v2 = await UserContract.methods.balanceOf(uniswap_address_v2).call();
    uniswap_balance_v3 = await UserContract.methods.balanceOf(uniswap_address_v3).call();
  } catch (error) {
    result(error, null);
    return;
  }
  if (parseInt(uniswap_balance_v2) === 0 && parseInt(uniswap_balance_v3))
    result(null, "Honeypot!!!");
  else
    result(null, "No Honeypot!!!");
  return;
}

exports.rugpull_check = async (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  contract_address = req.body.contract_address;
  await check_rugpull(contract_address, (err, data) => {
    if (err) {
      console.log(err);
      res.send({
        error: err,
        status: "error"
      });
    }
    else res.send({
      data: data,
      status: "success"
    });
  });
};
const check_rugpull = async (contract_address, result) => {
  let rst = "";
  const browser = await puppeteer.launch({ headless: process.env.DEV });
  try {
    const page = await browser.newPage();
    await page.goto(`https://etherscan.io/token/${contract_address}#balances`);
    console.log("111\n\n");
    try {
      const elementHandle = await page.waitForSelector('#tokeholdersiframe');
      console.log("222\n\n");
      const frame = await elementHandle.contentFrame();
      console.log("333\n\n");
      await frame.waitForSelector('#maintable');
      console.log("444\n\n");

      rst = await frame.evaluate(async () => {
        var data = [];
        var list = Array.from(document.querySelectorAll("table>tbody>tr"));
        console.log(list);
        if (list[0].querySelectorAll("td").length > 1) {
          list.forEach(element => {
            var tmpArray = {};
            tmpArray.address = element.querySelector("td:nth-of-type(2) a").getAttribute("href").slice(-42);
            tmpArray.quantity = element.querySelector("td:nth-of-type(3)").innerHTML;
            tmpArray.percentage = element.querySelector("td:nth-of-type(4)").innerText;
            data.push(tmpArray);
          });
        }
        return data;
      });
      console.log(rst, "\n\n");
      await browser.close();
      result(null, rst);
    } catch (err) {
      result(err, null);
    }
  } catch (err) {
    result(err, null);
  }
};