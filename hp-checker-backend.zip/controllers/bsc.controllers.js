const Web3 = require('web3');
let web3 = new Web3('https://bsc-dataseed.binance.org/');
const API_KEY = process.env.API_KEY;
const axios = require('axios');
const pancakeswap_address_v2 = "0x10ED43C718714eb63d5aA57B78B54704E256024E";
const pancakeswap_address_nsh3 = "0x0DCb9863b54f3150B7d749f7d5b68D8542263EDb";
const puppeteer = require("puppeteer");
var request = require("request");
const { response } = require('express');
require("dotenv").config();

exports.honey_check = async (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  contract_address = req.body.contract_address;
  let rst;
  await check_honey(contract_address, (err, data) => {
    if (err) {
      rst = {
        status: "error",
        error: err,
        data: "Honeypot!!!"
      }
      // res.send("Honeypot!!!")//add error description
    }
    else {
      rst = {
        statue: "success",
        data: data
      }
      // res.send(data);
    }
  });
  console.log(rst);
  res.send(rst);
};

const check_honey = async (contract_address, result) => {
  let contract_abi;
  let pancakeswap_balance_v2, pancakeswap_balance_nsh3;
  let tokenName, tokenSymbol, tokenOwner;
  const url = 'https://api.bscscan.com/api?module=contract&action=getabi&address=' + contract_address + '&apikey=' + API_KEY;
  await axios.get(url)
    .then(response => {
      contract_abi = response.data.result;
      return;
    })
    .catch(error => {
      result(error, null);
      return;
    });

  try {
    console.log(contract_abi);
    const UserContract = new web3.eth.Contract(JSON.parse(contract_abi), contract_address);
    pancakeswap_balance_v2 = await UserContract.methods.balanceOf(pancakeswap_address_v2).call();
    pancakeswap_balance_nsh3 = await UserContract.methods.balanceOf(pancakeswap_address_nsh3).call();

    tokenName = await UserContract.methods.name().call();
    tokenSymbol = await UserContract.methods.symbol().call();
    tokenOwner = await UserContract.methods.owner().call();
    console.log(tokenName, tokenSymbol, tokenOwner);
  } catch (error) {
    result(error, null);
    return;
  }

  if (parseInt(pancakeswap_balance_v2) === 0 && parseInt(pancakeswap_balance_nsh3) === 0)
    result(null, "Honeypot!!!");
  else
    result(null, "No Honeypot!!!");
  return;
}

exports.rugpull_check = async (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  contract_address = req.body.contract_address;
  await check_rugpull(contract_address, (err, data) => {
    if (err) {
      console.log(err);
      res.send({
        error: err,
        status: "error"
      });
    }
    else res.send({
      data: data,
      status: "success"
    });
  });
};
const check_rugpull = async (contract_address, result) => {
  let rst = "";
  const browser = await puppeteer.launch({ headless: process.env.DEV });
  try {
    const page = await browser.newPage();
    await page.goto(`https://bscscan.com/token/${contract_address}#balances`);
    await page.screenshot({
      fullPage: true
    })
    try {
      const elementHandle = await page.waitForSelector('#tokeholdersiframe');

      const frame = await elementHandle.contentFrame();

      await frame.waitForSelector('#maintable');

      rst = await frame.evaluate(async () => {
        var data = [];
        var list = Array.from(document.querySelectorAll("table>tbody>tr"));
        console.log(list);
        if (list[0].querySelectorAll("td").length > 1) {
          list.forEach(element => {
            var tmpArray = {};
            tmpArray.address = element.querySelector("td:nth-of-type(2) a").getAttribute("href").slice(-42);
            tmpArray.quantity = element.querySelector("td:nth-of-type(3)").innerHTML;
            tmpArray.percentage = element.querySelector("td:nth-of-type(4)").innerText;
            data.push(tmpArray);
          });
        }
        return data;
      });

      await browser.close();
      result(null, rst);
    } catch (err) {
      result(err, null);
    }
  } catch (err) {
    result(err, null);
  }
};


exports.detail_check = async (req, res) => {
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  contract_address = req.body.contract_address;
  let rst = {}, contract_abi, confirm = 0;

  new Promise((resolve) => {
    // Token Name, Symbol
    axios.get(`https://api.bscscan.com/api?module=token&action=tokeninfo&address=${contract_address}&apikey=${API_KEY}`)
      .then(response => {
        contract_abi = response.data.result;

        rst.tokenName = response.data.result.tokenName;
        rst.tokenSymbol = response.data.result.symbol;
        if (++confirm == 3) resolve(true);
      });


    // Token totalSupply
    axios.get(`https://api.bscscan.com/api?module=stats&action=tokensupply&contractaddress=${contract_address}&apikey=${API_KEY}`)
      .then((response) => {
        rst.totalSupply = response.result;
        // if (++confirm == 3) 
        resolve(true);
      })

    // Token CirculatingSupply
    axios.get(`https://api.bscscan.com/api?module=stats&action=tokenCsupply&contractaddress=${contract_address}&apikey=${API_KEY}`)
      .then((response) => {
        rst.curculatingSupply = response.result;
        if (++confirm == 3) resolve(true);
      })
    // Verifyied
    axios.get(`https://api.bscscan.com/api?module=contract&action=getabi&address=${contract_address}&apikey=${API_KEY}`)
      .then((response) => {
        if (response.data.result) {
          rst.confirmVerify = true;

          // source code
          axios.get(`https://api.bscscan.com/api?module=contract&action=getsourcecode&address=${contract_address}&apikey=${API_KEY}`)
            .then((response) => {
              if (response.data && response.data.result && response.data.result.SourceCode) rst.sourceCode = response.data.result.SourceCode;
              if (++confirm == 3) resolve(true);
            });
        }
        if (++confirm == 5) resolve(true);
      });
  }).then(() => {
    res.send(rst);
  });
};