# This is Backend using Node, for checking transfer transaction.

## Install node packages:
### npm install

## Running server:
### npm start

## You can test APIs with postman. Please check "PostmanTestExample" folder to see how to test APIs.

### - ethereum
api address : http://localhost:8080/api/check_eth_honeypot/

### - binance smart chain
api address : http://localhost:8080/api/check_bsc__honeypot/
